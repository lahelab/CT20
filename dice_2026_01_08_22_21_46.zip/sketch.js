function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("white");
fill ("black")
  circle (200,200,50)
  circle (300,300,50)
  circle (100,100,50)
}